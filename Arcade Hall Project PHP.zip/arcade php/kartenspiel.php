<?php
session_start();
$host = 'localhost';
$db = 'arcade';
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

try {
    if (isset($_SESSION['username'])) {
        $username = $_SESSION['username'];

        $sql = "SELECT tickets FROM users WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if ($user) {
            $_SESSION['tickets'] = $user['tickets'];
        } else {
            $_SESSION['tickets'] = 0; // Default value if user is not found
        }

        // Close statement and connection
        $stmt->close();
    }

    $conn->close();
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arcade - Card Game</title>
    <style><?php include "css/kartenspiel.css"?></style>
    <script src="js/kartenspiel.js"></script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Luckiest+Guy&display=swap" rel="stylesheet">
</head>

<body>
    <div id="container">

        <div id="title">
            <p>Card Game</p>
        </div>
        
        <div id="game">
            <div id="border">
                <div id="dealer"></div>

                <div id="points">
                    <div id="dealer_score">Dealer score: 0</div>
                    <div id="yourbet">Your Bet: </div>
                    <div id="player_score" style="margin-bottom: 30px;">Player score: 0
                </div>

                    <div id="buttons">
                        <button class="play" id="hit">Hit</button>
                        <button class="play" id="bet">Bet</button>
                        <button class="play" id="stay">Stay</button>
                    </div>
                    <br><input id="eingabe" type="number">
                </div>

                <div id="player"></div>
            </div>
        </div>

        <div id="footer">
            <a class="back" href="checkLogin.php">Back to Home</a>

            <?php


            if (isset($_GET['success']) && $_GET['success'] == 'true') {
                if (isset($_SESSION['tickets'])) {
                    echo '<p class="back" id="tickets">Your current Tickets: '.$_SESSION['tickets'].'</p>';
                }else{
                    echo '<p class="back">You must be logged in!</p>';
                }
             
            } else {
             echo '<p class="back">You must be logged in!</p>';
            }
            
            ?>
        </div>
    </div>
</body>

</html>