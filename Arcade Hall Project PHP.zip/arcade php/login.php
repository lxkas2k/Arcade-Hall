<?php 
session_start(); 


if (isset($_GET['success']) && $_GET['success'] == 'true') {
    echo '<div class="alert-container">';
    echo '<div class="alert-box">';
    echo '<p>You are successfully registered!</p>';
    echo '</div>';
    echo '</div>';
}


$host = 'localhost';
$db = 'arcade';
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['username']) && isset($_POST['password'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $sql = "SELECT * FROM users WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            if ($password === $user['password']) { 
                $_SESSION['username'] = $user['username'];
                $_SESSION['tickets'] = $user['tickets'];
                $_SESSION['loggedin'] = true;
                header("Location: http://localhost/arcade/index.php?success=true");
                exit();
            } else {
              echo '<div class="alert-container">';
              echo '<div class="alert-box">';
              echo '<p>Incorret password! Try again</p>';
              echo '</div>';
              echo '</div>';
            }
        } else {
            echo '<div class="alert-container">';
            echo '<div class="alert-box">';
            echo "No user found with that username.";
            echo '</div>';
            echo '</div>';
        }

        $stmt->close();
    } else {
        echo '<div class="alert-container">';
        echo '<div class="alert-box">';
        echo "Username or password is missing.";
        echo '</div>';
        echo '</div>';
    }
}

$conn->close();

?>
<!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
    <?php include "css/login.css" ?>
    <?php include "css/popup.css" ?>
    </style>

    <title>Arcade - Login</title>
  </head>
  <body>

      <div class="bg-image"></div>
      <div class="center">
        <h1>Login</h1>
        <form action="login.php" method="post" id="loginn">

          <div class="txt_field">
            <input type="text" id="username" name="username" required>
            <label  for="username">Username:</label>
          </div>

          <div class="txt_field">
            <input type="password" id="password" name="password" required>
            <label>Password:</label>

            <img class="eye" id="togglePassword" src="images/eye-slash-solid.svg">
          </div>
          <input type="submit" value="Login">
        </form>
          <div class="signup_link">
            Not registered yet? <a href="register.html">Register</a><br><br>
            Everything done? <a href="index.php">Back to Home</a>
          </div>
      <div>
      <script src="js/login.js"></script>
      <script src="js/popup.js"></script>
    </body>
</head>
</html>
  
  