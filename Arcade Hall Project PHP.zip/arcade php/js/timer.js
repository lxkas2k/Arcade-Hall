window.onload = function() {
    title = document.getElementById("title");
    time = document.getElementById("time");
    startT = document.getElementById("startT");
    startC = document.getElementById("startC");
    startR = document.getElementById("startR");
    startS = document.getElementById("startS");
    startCo = document.getElementById("startCo");
    inputC = document.getElementById("inputC");

    countT = 1;
    clicked = 1;
    countC = inputC.value;

    inputC.style.display="none";
    startR.style.display="none";
    startCo.style.display="none";
    startS.style.display="none";
    
    resetTimer = false;

    startR.addEventListener("click", function () {
        resetTimer = true;
        startT.style.display="inline";
        startC.style.display="inline";
        startR.style.display="none";
        startS.style.display="none";

        if (resetTimer == true) {
            time.innerHTML = "Time";
            clearInterval(timer);
        }

        clicked = 1;
        countT = 1;
    })

    startS.addEventListener("click", function () {
        clearInterval(timer);
        startS.style.display="none";
        startCo.style.display="inline";
    });

    startCo.addEventListener("click", function (){
        startS.style.display="inline";
        startCo.style.display="none";

        timer = setInterval(() => {
            time.innerHTML = countT + " Seconds";
            countT = countT + 1;
        }, 1000);
    });

    startT.addEventListener("click", function () {
        startT.style.display="none";
        startC.style.display="none";
        startCo.style.display="none";
        inputC.style.display="none";
        startS.style.display="inline";
        startR.style.display="inline";
        
        if(clicked == 1) {

        clicked = 0;

        timer = setInterval(() => {
            time.innerHTML = countT + " Seconds";
            countT = countT + 1;
        }, 1000);

        }
    })

    inputC.addEventListener("input", function() {
        if (inputC.value != "") {
            startC.disabled = false;
        } else {
            startC.disabled = true;
        }
    })

    startC.addEventListener("click", function () {

        inputC.style.display="inline";
        startT.style.display="none";
        title.innerHTML="Countdown";
        time.innerHTML="Countdown";

        startC.disabled = true;

        startC.addEventListener("click", function () {
        
        startC.style.display="none";
        inputC.style.display="none";

        if(clicked == 1) {

            countC = inputC.value;

            timer = setInterval(() => {

            time.innerHTML = countC;
            countC = countC - 1;

            if (countC <= -1) {
                time.innerHTML = "Time's up!";
                inputC.value = "";
                clearInterval(timer);
                startC.style.display="inline";
                inputC.style.display="inline";
            }

            }, 1000);
 
        }

        })
    })
}