document.addEventListener('DOMContentLoaded', function () {
    // Find the form element

    const passwordField = document.getElementById('password');
const passwordConfirm = document.getElementById('password_confirm')
const togglePassword = document.getElementById('togglePassword');
    const form = document.getElementById('register');

    // Attach event listener to form submit event
    form.addEventListener('submit', function (event) {
        // Prevent default form submission
        event.preventDefault();

        // Optionally, perform additional checks or actions
        // For example, validate form fields
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const passwordConfirm = document.getElementById('password_confirm').value;
        if (password.trim() !== passwordConfirm.trim()) {
            alert("The Password doesnt match");
            return;
        }else{
            form.submit();
        }

    });
    document.getElementById('togglePassword').addEventListener('click', function () {
        if (passwordField.type === 'password') {
            passwordField.type = 'text';
            togglePassword.src = 'images/eye-solid.svg';
        } else {
            passwordField.type = 'password';
            togglePassword.src = 'images/eye-slash-solid.svg';
        }
    
    });
});

