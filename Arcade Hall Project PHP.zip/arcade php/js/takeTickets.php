<?php
session_start();

$host = 'localhost';
$db = 'arcade';
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

    try {
        // Create connection
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $conn = new mysqli($host, $user, $pass, $db);

        // Prepare the SQL query with the new number

        $tickets = intval($_POST['number']);
        $username = $_SESSION['username'];

        $sql = "SELECT tickets FROM users where username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s",$username);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        $tickets = $user["tickets"] - $tickets;

        $sql = "UPDATE users SET tickets = ? where username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("is", $tickets,$username);
        
        // Execute the statement
        if ($stmt->execute()) {
            echo "Number updated successfully.";
        } else {
            echo "Error updating number: " . $stmt->error;
        }
        
        // Close statement and connection
        $stmt->close();
        $conn->close();
    }
    else{
        echo "chuj";
    }
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
?>