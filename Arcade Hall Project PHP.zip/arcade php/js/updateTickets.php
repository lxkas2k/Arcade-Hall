<?php
session_start();
function updateTickets(){
    $host = 'localhost';
$db = 'arcade';
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

    try {
        $conn = new mysqli($host, $user, $pass, $db);

        $username = $_SESSION['username'];

        $sql = "SELECT tickets FROM users where username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s",$username);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        $_SESSION['tickets'] = $user['tickets'];

        // Close statement and connection
        $stmt->close();
        $conn->close();
    }
    catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
}

?>