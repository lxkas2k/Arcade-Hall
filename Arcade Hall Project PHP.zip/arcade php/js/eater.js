window.onload = function() {
    
// Game constants
let GAME_WIDTH = window.innerWidth;
let GAME_HEIGHT = window.innerHeight;
const PLAYER_RADIUS = 20;
const MAX_CIRCLES = 200;
const SPAWN_INTERVAL = 100; 
const DISAPPEAR_THRESHOLD = 10; 

// Player variables
let playerX = GAME_WIDTH / 2;
let playerY = GAME_HEIGHT / 2;
let playerRadius = PLAYER_RADIUS;

// Circle variables
let circles = [];
let circleSpawnTimer = null;

// Center of the screen
let centerX = GAME_WIDTH / 2;
let centerY = GAME_HEIGHT / 2;

let gameIsOver = false;

const circleColors = ['red', 'green', 'yellow', 'orange', 'purple', 'pink'];

const canvas = document.getElementById('gameCanvas');
canvas.width = GAME_WIDTH;
canvas.height = GAME_HEIGHT;
const ctx = canvas.getContext('2d');

function drawPlayer() {
    // Draw white border
    ctx.fillStyle = 'white';
    ctx.beginPath();
    ctx.arc(playerX, playerY, playerRadius + 3, 0, Math.PI * 2); // Add a little extra radius for the border
    ctx.fill();

    // Draw blue circle
    ctx.fillStyle = 'blue';
    ctx.beginPath();
    ctx.arc(playerX, playerY, playerRadius, 0, Math.PI * 2);
    ctx.fill();
}

// Function to draw a circle
function drawCircle(x, y, radius, color) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.fill();
}

// Function to spawn a circle
function spawnCircle() {
    if (circles.length < MAX_CIRCLES) {
        let x = 0;
        let y = 0;
        const radius = Math.random() * (playerRadius * 1.3 + 10) + 10; 

        if (Math.round(Math.random()) == 0) {
            x = Math.random() * GAME_WIDTH;
            if (Math.round(Math.random()) == 0) {
                y = 0;
            } else {
                y = GAME_HEIGHT;
            }
        } else {
            y = Math.random() * GAME_HEIGHT;
            if (Math.round(Math.random()) == 0) {
                x = 0;
            } else {
                x = GAME_WIDTH;
            }
        }

        const speed = 1 + Math.random() * 2; 
        const color = circleColors[Math.floor(Math.random() * circleColors.length)]; 

        circles.push({ x, y, radius, speed, color });
    }
}

function update() {
    if (gameIsOver) return;

    ctx.clearRect(0, 0, GAME_WIDTH, GAME_HEIGHT);

    drawPlayer();

    for (let i = 0; i < circles.length; i++) {
        const circle = circles[i];
        drawCircle(circle.x, circle.y, circle.radius, circle.color);

        // Move circle towards the center
        const angle = Math.atan2(centerY - circle.y, centerX - circle.x);
        circle.x += Math.cos(angle) * circle.speed;
        circle.y += Math.sin(angle) * circle.speed;

        // Check distance to center to make circle disappear
        const distanceToCenter = Math.sqrt((centerX - circle.x) ** 2 + (centerY - circle.y) ** 2);
        if (distanceToCenter < DISAPPEAR_THRESHOLD) {
            // Remove circle from array
            circles.splice(i, 1);
            i--; // Adjust loop index
            continue; // Skip rest of the loop iteration
        }

        // Check collision with player
        const distanceToPlayer = Math.sqrt((playerX - circle.x) ** 2 + (playerY - circle.y) ** 2);
        if (distanceToPlayer < playerRadius && circle.radius < playerRadius) {
            // Player eats the circle
            playerRadius += 0.5; // Increase player's radius
            circles.splice(i, 1); // Remove circle from array
            i--; // Adjust loop index
        } else if (distanceToPlayer < circle.radius && circle.radius > playerRadius) {
            // Player is eaten by a larger circle
            gameOver();
            return;
        }

        // Wrap circles around the screen edges
        if (circle.x < -circle.radius) circle.x = GAME_WIDTH + circle.radius;
        if (circle.x > GAME_WIDTH + circle.radius) circle.x = -circle.radius;
        if (circle.y < -circle.radius) circle.y = GAME_HEIGHT + circle.radius;
        if (circle.y > GAME_HEIGHT + circle.radius) circle.y = -circle.radius;
    }
}

canvas.addEventListener('mousemove', function(event) {
    playerX = event.clientX;
    playerY = event.clientY;
});

circleSpawnTimer = setInterval(spawnCircle, SPAWN_INTERVAL);

setInterval(update, 1000 / 60);

function gameOver() {
    if (!gameIsOver) {
        gameIsOver = true;
        alert("Game Over! Your final size was: " + playerRadius);
        window.location.reload();
    }
}

window.addEventListener('resize', function() {
    GAME_WIDTH = window.innerWidth;
    GAME_HEIGHT = window.innerHeight;
    canvas.width = GAME_WIDTH;
    canvas.height = GAME_HEIGHT;
    centerX = GAME_WIDTH / 2;
    centerY = GAME_HEIGHT / 2;
});

}
