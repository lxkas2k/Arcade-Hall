document.addEventListener('DOMContentLoaded', () => {
    const player = document.getElementById('player');
    const obstacle = document.getElementById('obstacle');
    const timeCounter = document.getElementById('time-counter-value');
    const playButton = document.getElementById('play-button');
    const backToHomeLink = document.querySelector('#back-to-home a');

    const containerWidth = 1000; // Width of game container
    const containerHeight = 600; // Height of game container
    const playerWidth = 40; // Width of player
    const obstacleWidth = 40; // Width of obstacle
    const playerSpeed = 6; // Movement speed of player
    let obstacleSpeed = 3; // Movement speed of obstacle (initial)
    let playerLeft = containerWidth / 2 - playerWidth / 2; // Initial position of player (centered)
    let obstacleTop = -40; // Initial position of obstacle (top)
    let gameTime = 0; // Game time in milliseconds
    let gameIntervalId = null; // Interval ID for game loop
    let speedIncreaseIntervalId = null; // Interval ID for increasing obstacle speed
    let gameOver = false; // Game over flag
    let gameStarted = false; // Game started flag

    // Update player position
    function updatePlayer() {
        // Ensure player stays within game container bounds
        if (playerLeft < 0) {
            playerLeft = 0;
        } else if (playerLeft > containerWidth - playerWidth) {
            playerLeft = containerWidth - playerWidth;
        }
        player.style.left = `${playerLeft}px`;
    }

    // Update obstacle position
    function updateObstacle() {
        obstacle.style.top = `${obstacleTop}px`;
    }

    // Move obstacle downward
    function moveObstacle() {
        obstacleTop += obstacleSpeed;
        if (obstacleTop > containerHeight) { // Reset obstacle position if it goes below screen
            obstacleTop = -40;
            obstacle.style.left = `${Math.random() * (containerWidth - obstacleWidth)}px`; // Randomize obstacle horizontal position
        }
        updateObstacle();
    }

    // Update game time counter
    function updateGameTime() {
        gameTime += 20; // Increment by the interval (20ms in this case)

        // Calculate minutes, seconds and milliseconds
        let minutes = Math.floor(gameTime / (1000 * 60));
        let seconds = Math.floor((gameTime % (1000 * 60)) / 1000);

        // Ensure two digits format
        let formattedTime = `${pad2(minutes)}:${pad2(seconds)}`;
        timeCounter.textContent = formattedTime;
    }

    // Function to pad single digit numbers with leading zeros
    function pad2(number) {
        return (number < 10 ? '0' : '') + number;
    }

    // Start the game
    function startGame() {
        if (!gameStarted) {
            gameStarted = true; // Mark game as started
            playButton.disabled = true; // Disable play button after starting

            resetGame(); // Reset game state
            gameIntervalId = setInterval(() => {
                moveObstacle();
                checkCollision();
                updateGameTime(); // Update der Spielzeit
            }, 20);

            // Jede 5 Sekunden: Speed wird erhöht
            speedIncreaseIntervalId = setInterval(() => {
                obstacleSpeed += 0.5;
            }, 5000);
        }
    }

    // EventListener für den Play Button
    playButton.addEventListener('click', () => {
        startGame();
    });

    // EventListener für das Movement
    document.addEventListener('keydown', (event) => {
        if (!gameOver && gameStarted) {
            if (event.key === 'ArrowLeft' && playerLeft > 0) {
                playerLeft -= playerSpeed;
                updatePlayer();
            } else if (event.key === 'ArrowRight' && playerLeft < containerWidth - playerWidth) {
                playerLeft += playerSpeed;
                updatePlayer();
            }
        }
    });

    // Game loop
    function gameLoop() {
        if (!gameOver && gameStarted) {
            requestAnimationFrame(gameLoop);
        }
    }

    // Check collision between player and obstacle
    function checkCollision() {
        const playerRect = player.getBoundingClientRect();
        const obstacleRect = obstacle.getBoundingClientRect();

        if (playerRect.bottom > obstacleRect.top &&
            playerRect.top < obstacleRect.bottom &&
            playerRect.right > obstacleRect.left &&
            playerRect.left < obstacleRect.right) {
            gameOver = true;
            clearInterval(gameIntervalId);
            clearInterval(speedIncreaseIntervalId);
            alert('Game Over!');
            location.reload(); // Reload the page after game over
        }
    }

    // Reset game after game over
    function resetGame() {
        playerLeft = containerWidth / 2 - playerWidth / 2; // Reset player position to center
        obstacleTop = -40; // Reset obstacle position
        gameTime = 0; // Reset game time
        obstacleSpeed = 3; // Reset obstacle speed
        timeCounter.textContent = '00:00'; // Reset time counter display
        gameOver = false; // Reset game over flag
    }

    // Event listener for Back to Home link
    backToHomeLink.addEventListener('click', () => {
        clearInterval(gameIntervalId);
        clearInterval(speedIncreaseIntervalId);
        resetGame();
        location.reload(); // Reload the page to go back to home
    });
});
