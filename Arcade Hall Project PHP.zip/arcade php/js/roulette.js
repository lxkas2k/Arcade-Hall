window.onload = function () {

    const wheel = document.getElementById("wheel");
    const bet = document.getElementById("spin");
    const green = document.getElementById("green");
    const black = document.getElementById("black");
    const red = document.getElementById("red");
    const arrow = document.getElementById("arrow");
    var scrollAmount = 0;
    var step = 10 // Adjust the step size for smoother/slower scrolling
    var itemWidth = 100; // Width of each item
    var totalItems = 60; // Total number of items
    var clicked = false;
    var potentialWin = 0;
    red.statusClicked = true;
    green.statusClicked = true;
    black.statusClicked = true;

    function addTickets(newNumber) {
        const formData = new FormData();
        formData.append('number', newNumber);
    
        fetch('js/addTickets.php', {
            method: 'POST',
            body: formData
        })
        .catch(error => {
            console.error('Error:', error); // Log any errors
        });
    }
    function takeTickets(newNumber) {
        const formData = new FormData();
        formData.append('number', newNumber);
    
        fetch('js/takeTickets.php', {
            method: 'POST',
            body: formData
        })
        .catch(error => {
            console.error('Error:', error); // Log any errors
        });
    }
    
    

    function showNotification() {
        const notification = document.getElementById('notification');
        notification.style.display = 'block';

        // Add animation class
        notification.classList.add('notification-show');

        // Automatically close after 5 seconds
        setTimeout(() => {
            closeNotification();
        }, 3000);
    }

    function closeNotification() {
        const notification = document.getElementById('notification');

        // Remove animation class
        notification.classList.remove('notification-show');

        // Hide notification after animation
        setTimeout(() => {
            notification.style.display = 'none';
        }, 300); // Should match CSS animation duration
    }

    for (let i = 0; i < 100; i++) { // Erstellen von den Roulette Fekder
        const divElement = document.createElement("div");
        divElement.style.display = "inline-block";
        divElement.style.width = "100px";
        divElement.style.height = "100px";
        divElement.id = "color_bet";
        if (i % 2 == 0) {
            divElement.style.backgroundColor = "red"
        } else if (i % 31 == 0) {
            divElement.style.backgroundColor = "green"
        }
        else {
            divElement.style.backgroundColor = "black"
        }
        wheel.appendChild(divElement);
    }
    function stopAtRandomItem() {
        // Calculate the number of items visible within the container
        var visibleItems = Math.floor(wheel.clientWidth / itemWidth);

        // Calculate the range within which the wheel can stop
        var maxStopPosition = totalItems - visibleItems; // Maximum position to stop

        // Generate a random position within the allowed range
        var randomPosition = Math.floor(Math.random() * (maxStopPosition + 1));

        // Calculate the scroll position to stop at
        var stopScrollPosition = randomPosition * itemWidth + 45; // Adjusted stop position

        // Animate the scroll to stopScrollPosition
        animateScroll(stopScrollPosition);
    }

    function animateScroll(targetPosition) {
        var start = wheel.scrollLeft;
        var distance = targetPosition - start;
        var duration = 1000; // Animation duration in milliseconds
        var startTime = null;

        function animationStep(timestamp) {
            if (!startTime) startTime = timestamp;
            var progress = timestamp - startTime;
            var ease = easeOutQuart(progress, start, distance, duration);
            wheel.scrollLeft = ease;
            if (progress < duration) {
                requestAnimationFrame(animationStep);
            }
        }

        requestAnimationFrame(animationStep);
    }

    // Easing function for smooth animation
    function easeOutQuart(t, b, c, d) {
        t /= d;
        t--;
        return -c * (t * t * t * t - 1) + b;
    }

    // Event listener for the "Bet" button click
    var spinButton = document.getElementById("spin");
    spinButton.addEventListener("click", function () {
        var tickets = document.getElementById("tickets-container").value.trim();
        if (tickets === '') {
            alert("bet tickets!");
            return;
        }

        if( red.statusClicked == true && green.statusClicked == true && black.statusClicked == true) {
            alert("Choose a color!")
            return;
        }

        var tickets2 = document.getElementById("tickets2");

        let saveTickets = tickets2.innerHTML;

        function extractIntFromString(str) {
            const result = str.match(/\d+/);
            return result ? parseInt(result[0], 10) : null;
        }
    
        const ticketsSave = extractIntFromString(saveTickets);

        console.log(ticketsSave);
        if (ticketsSave <= 0) {
            return;
        }
        
        // Reset variables and start scrolling
        var scrollAmount = 0;
        var intervalTime = 1;
        setTimeout(stopAtRandomItem, intervalTime);
        setTimeout(function () {

            const arrow = document.getElementById("arrow");

            // Get the position and dimensions of the arrow element
            const rect = arrow.getBoundingClientRect();

            // Calculate the center coordinates of the arrow
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;
            const elementUnderArrow = document.elementFromPoint(centerX, centerY + 50);

            var color = elementUnderArrow.style.backgroundColor;
            if (color == "red" && red.statusClicked == false) {
                showNotification();
                addTickets(potentialWin/2);
            } else if (color == "black"&& black.statusClicked == false) {
                showNotification();
                addTickets(potentialWin/2);
            } else if (color == "green" && green.statusClicked == false) {
                addTickets(potentialWin/2);
            }
            else{
                takeTickets(potentialWin/2);
            }
            setTimeout(function(){
                location.reload();
            },1000);

        }, 1000)
    });
    function buttonClicked(multiplier, event) {

        function setButtons(mainobj, obj1, obj2) {
            if (mainobj.statusClicked == true) { // turn off
                mainobj.statusClicked = false;
                mainobj.style.border = "2px solid white"
                obj1.disabled = true;
                obj2.disabled = true;
                potentialWin = tickets * multiplier;
            }
            else if (mainobj.statusClicked == false) { // turn on
                mainobj.style.border = "none"
                mainobj.statusClicked = true;
                obj1.disabled = false;
                obj2.disabled = false;
                potentialWin = 0;
            }
        }

        var tickets = document.getElementById("tickets-container").value.trim();
        if (tickets === '') {
            alert("bet tickets!");
            return;
        }
        if (this == red) {
            setButtons(red, black, green);
        }
        if (this == black) {
            setButtons(black, green, red);
        }
        if (this == green) {
            setButtons(green, black, red);
        }
        document.getElementById("yourBet").innerHTML = "Potential win: " + potentialWin;

        if (red.statusClicked == false) {
            spinButton.style.backgroundColor = "red";
        }
        else if (black.statusClicked == false) {
            spinButton.style.backgroundColor = "black";
        }
        else if (green.statusClicked == false) {
            spinButton.style.backgroundColor = "green";

        } else {
            spinButton.style.backgroundColor = "#5449dc";
        }
    }



    red.addEventListener("click", buttonClicked.bind(red, 2));
    black.addEventListener("click", buttonClicked.bind(black, 2));
    green.addEventListener("click", buttonClicked.bind(green, 14));

}