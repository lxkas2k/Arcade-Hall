window.onload = function() {
    cal = document.getElementById("calculate");
    result = document.getElementById("result-bmi");

    cal.addEventListener("click", function() {

        height = parseFloat(document.getElementById("height").value / 100);
        weight = parseFloat(document.getElementById("weight").value);

        if (weight != "" && height != "") {
            const bmi = weight / (height * height);
            calBMI(bmi);
        } else {
            alert('Please enter weight and height.');
        }
    });

    function calBMI(bmi) {

        let status = '';

        if (bmi < 18.5) {
            status = 'James (Magersüchtig)';
        } else if (bmi >= 18.5 && bmi < 24.9) {
            status = 'Normalweight';
        } else if (bmi >= 25) {
            status = 'Fettsack';
        }
        console.log(bmi);
        result.innerHTML = bmi.toFixed(2) + "<br>" + status;
    }
}
