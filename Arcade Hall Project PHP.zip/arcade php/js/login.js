window.onload = function(){
    const passwordField = document.getElementById('password');
    const togglePassword = document.getElementById('togglePassword');
    const loginButton = document.getElementById("loginButton");
    document.getElementById('togglePassword').addEventListener('click', function(){
        if (passwordField.type === 'password') {
            passwordField.type = 'text';
            togglePassword.src = 'images/eye-solid.svg'; 
        } else {
            passwordField.type = 'password';
            togglePassword.src = 'images/eye-slash-solid.svg'; 
        }
    });
// Assuming you have a form with id 'myForm' and fields 'username' and 'password'
var form = document.getElementById('login');

form.addEventListener('submit', function(event) {
    event.preventDefault();  // Prevent the form from submitting normally

    var formData = new FormData(form);  // Create a FormData object from the form

    // Log username and password to console
    var username = formData.get('username');
    var password = formData.get('password');
    ale('Username:', username);
    console.log('Password:', password);
});
}
