export function addTickets(newNumber) {
    const formData = new FormData();
    formData.append('number', newNumber);

    fetch('addTickets.php', {
        method: 'POST',
        body: formData
    })
    .catch(error => {
        console.error('Error:', error); // Log any errors
    });
}
export function tackeTickets(newNumber) {
    const formData = new FormData();
    formData.append('number', newNumber);

    fetch('takeTickets.php', {
        method: 'POST',
        body: formData
    })
    .catch(error => {
        console.error('Error:', error); // Log any errors
    });
}


// Example usage: Update the number to 2000
updateNumber(2000000);