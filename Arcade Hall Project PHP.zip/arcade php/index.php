<?php
session_start();
if (isset($_GET['success']) && $_GET['success'] == 'true') {
$host = 'localhost';
$db = 'arcade';
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

    try {
        $conn = new mysqli($host, $user, $pass, $db);

        $username = $_SESSION['username'];

        $sql = "SELECT tickets FROM users where username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s",$username);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        $_SESSION['tickets'] = $user['tickets'];

        // Close statement and connection
        $stmt->close();
        $conn->close();
    }
    catch (Exception $e) {
        echo "Error: " . $e->getMessage();
}
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arcade Hall</title>
    <style>
    <?php include "css/style.css"?>
    </style>
    <script src="js/script.js"></script>
    <script src="js/popup.js"></script>
    <style>#a {color: #280e7a}</style>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Luckiest+Guy&display=swap" rel="stylesheet">

</head>
<body>

<?php
if (isset($_GET['success']) && $_GET['success'] == 'true') {
    if (isset($_SESSION['username'])) {
        $name =  $_SESSION['username'];
    } else {
        $name = "NULL";
    }
    if (isset($_SESSION['tickets'])) {
        $tickets =  $_SESSION['tickets'];
    } else {
        $tickets = "NULL";
    }

    echo '<div class="dropdown-container">' .
    '<img id="dropdown" src="images/pfeilneu.png" onclick="toggleLoginBox()">' .
    '<div class="login-box" id="loginBox">' .
    '<p>Welcome ' . $name . '</p> ' .
    '<img class="login-img" src="images/founder1.png" alt="Profile Image">' .
    '<p>Your Tickets: ' . $tickets . '</p>' .
    '</div>' .
    '</div>';

    echo '<div class="alert-container">';
    echo '<div class="alert-box">';
    echo '<p>You are successfully logged in!</p>';
    echo '</div>';
    echo '</div>';
}
?>
    <div class="bg-image"></div>
    
        <div class="bg-text">

            <div class="typewriter">
                <h1 class="typewriter-text">The Arcade Hall</h1>
            </div>

            <button id="scroll-about">➥ About Us</button><br><br>
            <button id="scroll-founder">➥ Founder</button><br><br>
            <button id="scroll-games">➥ Games</button><br><br>
            <button id="scroll-applications">➥ Applications</button><br><br>
            <?php 
            if (isset($_GET['success']) && $_GET['success'] == 'true') {
                echo '<a class="login-text" id="signOut" href="index.php">Sign Out</a>';
            } else {
                echo '<div id="login"><a class="login-text" href="login.php">Login</a></div><br>';
                echo '<div id="signup"><a class="signup-text" href="register.html">Sign In</a></div><br>';
            }
            
            ?>
        </div>

        <div id="animation">
            <div class="typewriter2">
                <h1 id="about" class="typewriter-text"><u>About Us</u></h1>
            </div>
        </div>

        <p class="text-about">
            Welcome to the Arcade Hall Website!<br>
            This Website got created, to entertain everybody with some awesome Games<br>
            <br>
            The Arcade Hall has Games like Fortune Wheel, Card Game, Eater and many more<br>
        </p>

        <div id="animation">
            <div class="typewriter2">
                <h1 id="founder" class="typewriter-text"><u>Founder</u></h1>
            </div>
        </div>

        <div class="image-styleFounder">
            <div class="image-wrapperFounder">
                <img class="bild" src="images/founder.png" alt="Lukas"></a>
                <div class="overlay">Lukas Zasada<br>|<br>Founder - Frontend<br>|<br>Hans Sachs-Berufskolleg</div>
            </div>

            <div class="image-wrapperFounder">
                <img class="bild" src="images/founder1.png" alt="Pawel"></a>
                <div class="overlay">Pawel Kurczak<br>|<br>Founder - Backend<br>|<br>Hans Sachs-Berufskolleg</div>
            </div>

            <div id="animation">
                <div class="typewriter2">
                    <h1 id="games"><u>Games</u></h1>
                </div>
            </div>

    <div class="image-style">
        <div id="imagewrapperphp2" class="image-wrapper">

            <img class="image1" src="images/glücksrad.png" alt="Glücksrad"></a>
            <div class="overlay">Fortune Wheel<br><br><p class="text-intro">Bet your Tickets on a color.</p></div>
        </div>

        <div class="image-wrapper">
            <a href="snake.html">
            <img class="image3" src="images/snake.png" alt="Snake"></a>
            <div class="overlay">Snake<br><br><p class="text-intro">Eat and get bigger.</p></div>
        </div>

        <div id="imagewrapperphp" class="image-wrapper">
            
            <img class="image3" src="images/kartenspiel.png" alt="Kartenspiel"></a>
            <div class="overlay">Card Game<br><br><p class="text-intro">Bet your Tickets and win.</p></div>
        </div>
        <br><br><br>
        <div class="image-wrapper"><a href=""></a>
            <a href="eater.html">
            <img class="image4" src="images/amamam.gif" alt="Eater"></a>
            <div class="overlay">Eater<br><br><p class="text-intro">Eat and get bigger.</p></div>
        </div>

        <div class="image-wrapper">
            <a href="dodger.html">
            <img class="image2" src="images/attacker.png" alt="Dodger"></a>
            <div class="overlay">Dodger<br>(Dodger - AI Created)<br><br><p class="text-intro">Dodge and beat the time.<br>Every 15 seconds is the enemy faster!</p></div>
        </div>

        <div class="image-wrapper">
            <a href="aimlabs.html">
            <img class="image3" src="images/aims.png" alt="Aim Labs"></a>
            <div class="overlay">Arcade Aims<br><br><p class="text-intro">Proof your aim.</p></div>
        </div>
        
        <div id="animation">
            <div class="typewriter2">
                <h1 id="anwendung"><u>Anwendungen</u></h1>
            </div>
        </div>

        <br><br><br>
        <div class="image-wrapper"><a href=""></a>
            <a href="cal.html">
            <img class="image3" src="images/cal.png" alt="Calculator"></a>
            <div class="overlay">Calculator</div>
        </div>
        
        <div class="image-wrapper">
            <a href="timer.html">
            <img class="image2" src="images/timer.png" alt="Timer"></a>
            <div class="overlay">Timer</div>
        </div>
        
        <div class="image-wrapper">
            <a href="bmi.html">
            <img class="image2" src="images/bmi.png" alt="BMI Calculator"></a>
            <div class="overlay">BMI Calculator</div>
        </div>
    </div>
    <p id="copyright">&copy; <span id="currentYear"></span> The Arcade Hall.</p>
    <p id="a">a</p>

    <script>
         function toggleLoginBox() {
        const loginBox = document.getElementById('loginBox');
        if (loginBox.style.display === 'none' || loginBox.style.display === '') {
            loginBox.classList.toggle('active');
        }
         }
    </script>
</body>
</html>