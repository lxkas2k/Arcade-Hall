<?php
session_start();

$host = 'localhost';
$db = 'arcade';
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

    try {
        $conn = new mysqli($host, $user, $pass, $db);

        $username = $_SESSION['username'];

        $sql = "SELECT tickets FROM users where username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s",$username);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        $_SESSION['tickets'] = $user['tickets'];

        // Close statement and connection
        $stmt->close();
        $conn->close();
    }
    catch (Exception $e) {
        echo "Error: " . $e->getMessage();
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Casino - Projekt</title>
    <style>
    <?php include "css/roulette.css"?>
    </style>
    <script type="module" src="js/roulette.js"></script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Luckiest+Guy&display=swap" rel="stylesheet">
</head>

<body>
    <audio id="myAudio">
        <source src="images/bigwin.m4a" type="audio/mp4" id="casino_big_win">
      </audio>
    <div id="notification" class="notification">
        <div class="notification-content">
          <div class="notification-icon">
            🎉
          </div>
          <div class="notification-message">
            You've won!
          </div>
        </div>
      </div>
    <div class="title">
        <h1 class="title-text">Fortune Wheel</h1>
    </div>

    <div id="roulette_container">
        <div id="arrow"></div>
        <div id="wheel"></div>
        <p id="yourBet">Potential win: </p>
    </div>

    <div id="betting">
        <div id="betting-box">
            <div id="tickets-box">
                <p id="tickets">Tickets</p>
                <input id="tickets-container" type="number" type="text">
            </div>
        </div>

        <div>
            <button id="spin">Spin</button>
        </div>

        <div class="color-menu">
            <button id="green"></button>
            <button id="red"></button>
            <button id="black"></button>
        </div>

        <a id="back" href="checkLogin.php">Back to Home</a>
        
        <?php

        if (isset($_GET['success']) && $_GET['success'] == 'true') {
          if (isset($_SESSION['tickets'])) {
          echo '<p id="tickets2">Your current Tickets: '.$_SESSION['tickets'].'</p>';
        } else { 
          echo '<p class="back">You must be logged in!</p>';
        }
        } else {
          echo '<p class="back">You must be logged in!</p>';
        }

        ?>

    </div>

</body>

</html>