window.onload = function () {

    x = Math.random() * (1350 - 170) + 170;
    y = Math.random() * (755 - 95) + 95;

    const spawnInterval = 1000;
    var count = 0;
    var time = 60;
    var aimed = 0;
    var missed = 0;
    clicked = true;

    function createCircle(x, y,size,color) {
        border = document.getElementById("border");
        start2 = document.getElementById("start2");
        score = document.getElementById("title-score");
        start = document.getElementById("start");
        timer = document.getElementById("timer");
        circle = document.createElement("div");
        circle.style.width = size + "px";
        circle.style.height = size + "px";
        circle.style.backgroundColor = color;
        circle.style.borderRadius = "50%";
        circle.style.position = "absolute";
        circle.id = "kreis";
        circle.style.top = y + "px";
        circle.style.left = x + "px";
        border.append(circle);

        var clickDetected = false;

        // Function to execute if nothing was clicked within 1000 milliseconds (1 second)
        function handleNoClick() {
            x = Math.random() * (1350 - 170) + 170;
            y = Math.random() * (755 - 95) + 95;
            circle.remove();
            createCircle(x, y,size,color)
        }

        // Event listener for clicks on a specific element (replace 'element' with your target element)
                
        circle.addEventListener("click", function () {
            clickDetected = true;
            x = Math.random() * (1350 - 170) + 170;
            y = Math.random() * (755 - 95) + 95;

            circle.remove();
            createCircle(x, y,size,color);

            count = count + 1;
            score.innerHTML = "Score: " + count;

        });
        if(!clicked){

        setTimeout(function () {
            if (!clickDetected) {
                handleNoClick();
                count--;
                score.innerHTML = "Score: " + count;
            }
        }, 1000);
    }
    }

    start2.addEventListener("click", function () {

        if (clicked == true) {
            clicked = false;
            createCircle(x, y,45,"yellow");

            timer.innerHTML = "60";

            clear = setInterval(function () {
                timer.innerHTML = time - 1;
                time = time - 1;

                if (time <= 0) {
                    
                    console.log(0 / 0);
                    alert("Time is up! Your Score is: " + count);
                    count = 1;
                    clearInterval(clear);
                    time = 60;
                    timer.innerHTML = "";
                    clicked = true;

                    setTimeout(function(){border.innerHTML = "";},10);
                }

            }, 1000);

        }
    });

    start.addEventListener("click", function () {

        if (clicked == true) {
            clicked = false;
            createCircle(x, y,75,"red");

            document.addEventListener("click", function (event) {

                if (event.target.id == "kreis") {
                    console.log(aimed);
                    aimed = aimed + 1;
                } else {
                    console.log(missed);
                    missed = missed +1;
                }

            });

            timer.innerHTML = "60";

            clear = setInterval(function () {
                timer.innerHTML = time - 1;
                time = time - 1;

                if (time <= 0) {
                    
                    console.log(0 / 0);
                    alert("Time is up! Your Score is: " + count);
                    count = 1;
                    clearInterval(clear);
                    time = 60;
                    timer.innerHTML = "";
                    clicked = true;

                    setTimeout(function(){border.innerHTML = "";},10);
                }

            }, 1000);

        }
    });
}