document.addEventListener('DOMContentLoaded', function () {
    // Find the form element

    const passwordField = document.getElementById('password');
    const passwordConfirm = document.getElementById('password_confirm')
    const togglePassword = document.getElementById('togglePassword');
    const form = document.getElementById('register');
    const pw = document.getElementById('pw-title');
    const pwreq = document.getElementById('pw-req');
    const center = document.getElementById('center');


    // Attach event listener to form submit event
    form.addEventListener('submit', function (event) {
        
        // Prevent default form submission
        event.preventDefault();

        // Optionally, perform additional checks or actions
        // For example, validate form fields
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const passwordConfirm = document.getElementById('password_confirm').value;

        let specialChars = [' ', '!', '?', '"', '#', '%', '&', '{', '}', '(', ')', '[', ']', '\\', '/', '<', '>', '*', ' ', '$', ':', ';', '@', '+', '-', '=', '\u00A7']
        var noSpecialChar = false;

        if (username.length <= 3) {
            alert("Username is too short. Minimum 4 letters!");
            return;
        }

        for (let i = 0; i < specialChars.length; i++) {

            if (username.includes(specialChars[i]) == true) {
                alert("Don't use special characters!");
                return;

            }
            
            if (password.includes(specialChars[i]) == false) {
                noSpecialChar = true;

            } else {
                noSpecialChar = false;
                break;
            }
        }

        if (noSpecialChar) {
            alert("Use minimum one special character!");
            return;
        }


        if (/[A-Z]/.test(password) == false) {
            alert("Use minimum one uppercase letter!");
            return;
        }

        if (/[0-9]/.test(password) == false) {
            alert("Use at least one number!");
            return;
        }


        if (password.length <= 7) {
            alert("Password is too short. Minimum 8 letters!");
            return;
        }


        if (password.trim() !== passwordConfirm.trim()) {
            alert("The Password doesnt match");
            return;
        } else {

            // For demonstration purposes, we will send a basic POST request to a server
            fetch('/signup', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ 
                    username:username,
                    password:password,
                    passwordConfirm:passwordConfirm
                })
            })
            .then(response => response.json())
            .then(data => {
                let alert = document.getElementById("alertbox");
                if(data.signedIn){
                    window.location.href = "/login";
                }else{
                    alert.innerHTML = data.error;
                    console.log(alert.style.display);
                    alert.style.display = "block";
                    console.log(alert.style.display);
                    setTimeout(() => {
                        alert.style.display = "none";
                    }, 3000);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        }

    });
    document.getElementById('togglePassword').addEventListener('click', function () {
        const passwordField = document.getElementById('password');
        const confirmPasswordField = document.getElementById('password_confirm');
        const togglePassword = document.getElementById('togglePassword');

        if (passwordField.type === 'password') {
            passwordField.type = 'text';
            confirmPasswordField.type = 'text';
            togglePassword.src = 'images/eye-solid.svg';
        } else {
            passwordField.type = 'password';
            confirmPasswordField.type = 'password';
            togglePassword.src = 'images/eye-slash-solid.svg';
        }
    });

    let isPwreq = false;

    pw.addEventListener('click', function() {

        if(isPwreq) {
            pwreq.innerHTML = '';

        } else {
            pwreq.innerHTML = '&#8226; Use at least 8 letters!<br>&#8226; Use at least one special character!<br>&#8226; Use at least one uppercase letter!<br>&#8226; Use at least one number!';
        }

        isPwreq = !isPwreq;
    });
});

