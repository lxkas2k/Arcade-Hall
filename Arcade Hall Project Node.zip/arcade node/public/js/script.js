document.addEventListener("DOMContentLoaded", function () {
    const scrollButtonAboutUs = document.getElementById("scroll-about");
    const signOut = document.getElementById("signOut");
    const scrollapplications = document.getElementById("scroll-applications");
    const scrollButtonFounder = document.getElementById("scroll-founder");
    const scrollButtonGames = document.getElementById("scroll-games");
    scrollButtonAboutUs.addEventListener("click", function () {
        // Find the element you want to scroll to
        var elementToScrollTo = document.querySelector("#animation");

        // Scroll to the element
        elementToScrollTo.scrollIntoView({
            behavior: "smooth", // Smooth scrolling
        });
    });


    scrollButtonFounder.addEventListener("click", function () {
        // Find the element you want to scroll to
        var elementToScrollTo = document.querySelector("#founder");

        // Scroll to the element
        elementToScrollTo.scrollIntoView({
            behavior: "smooth", // Smooth scrolling
        });
    });



    scrollButtonGames.addEventListener("click", function () {
        // Find the element you want to scroll to
        var elementToScrollTo = document.querySelector("#games");

        // Scroll to the element
        elementToScrollTo.scrollIntoView({
            behavior: "smooth", // Smooth scrolling
        });

    });

    scrollapplications.addEventListener("click", function () {

        var elementToScrollTo = document.querySelector("#anwendung");

        // Scroll to the element
        elementToScrollTo.scrollIntoView({
            behavior: "smooth", // Smooth scrolling
        });
    });

});


