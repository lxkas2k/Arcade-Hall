window.onload = function() {

    plus = document.getElementById("plus");
    minus = document.getElementById("minus");
    mal = document.getElementById("mal");
    geteilt = document.getElementById("geteilt");

    wurzel= document.getElementById("wurzel");
    potenz = document.getElementById("potenz");
    hoch2 = document.getElementById("hoch2");
    reset = document.getElementById("reset");

    input1 = document.getElementById("input1");
    input2 = document.getElementById("input2");
    result = document.getElementById("result-value");

    plus.addEventListener("click", function() {
        const x = parseInt(input1.value, 10);
        const y = parseInt(input2.value, 10);
        result.innerHTML = x + y;
    });

    minus.addEventListener("click", function() {
        const x = parseInt(input1.value, 10);
        const y = parseInt(input2.value, 10);
        result.innerHTML = x - y;
    });

    mal.addEventListener("click", function() {
        const x = parseInt(input1.value, 10);
        const y = parseInt(input2.value, 10);
        result.innerHTML = x * y;
    });

    geteilt.addEventListener("click", function() {
        const x = parseInt(input1.value, 10);
        const y = parseInt(input2.value, 10);
        result.innerHTML = x / y;
    });

    wurzel.addEventListener("click", function() {
        const x = parseFloat(input1.value);
            const sqrt = Math.sqrt(x);
            result.innerHTML = sqrt.toFixed(2);
    });

    potenz.addEventListener("click", function() {
        const x = parseFloat(input1.value); // base
        const y = parseFloat(input2.value); // exponent
        const erg = x ** y;
        result.innerHTML = erg.toFixed(2);
    });

    hoch2.addEventListener("click", function() {
        const x = parseInt(input1.value, 10);
        result.innerHTML = x * x;
    });

    reset.addEventListener("click", function() {
        input1.value = "";
        input2.value = "";
        result.innerHTML = "RESULT";
    });
}