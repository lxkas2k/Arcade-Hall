function toggleBox(boxId) {
    // Get the clicked button and corresponding content box
    const button = document.getElementById(boxId.replace('Box', ''));
    const contentBox = document.getElementById(boxId);

    // Check if the content box is currently visible
    const isVisible = contentBox.classList.contains('show');

    // Get all content boxes
    const contentBoxes = document.querySelectorAll('.content');

    // Hide all content boxes
    contentBoxes.forEach(box => {
        box.classList.remove('show');
    });
    // If the content box was not already visible, show it
    if (!isVisible) {
        contentBox.classList.add('show');
    }
}
window.onload = function () {

    const usernameBox = document.getElementById("usernameBox");
    const submitButton = document.getElementById("submitButton");


    const fileInput = document.getElementById('fileInput');
    const profilePic = document.getElementById('profilePic');

    fileInput.addEventListener('change', function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                profilePic.style.backgroundImage = `url(${e.target.result})`;
            };
            reader.readAsDataURL(file);
        }
    });
        const changeUsernameForm = document.getElementById("changeUsernameForm");
    
        changeUsernameForm.addEventListener("submit", (e) => {
            e.preventDefault(); // Corrected method name from defaultPrevented to preventDefault
    
            const username = document.getElementById("username").value;
            const password = document.getElementById("password").value;
    
            fetch('/changeUsername', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    username: username,
                    password: password
                })
            })
            .then(response => response.json())
            .then(msg => {
                console.log(msg.error)
                if (msg.error) {
                    if(msg.error == "Success!"){
                        document.getElementById("notification").style.display = "block"
                    document.getElementById("notification").innerHTML = "You've changed your username!";
                    setTimeout(() => {
                        document.getElementById("notification").style.display = "none"
                        window.location.href = "/signout"
                    }, 3000);
                    return;
                    }
                    document.getElementById("notification").style.display = "block"
                    document.getElementById("notification").innerHTML = msg.error;
                    setTimeout(() => {
                        document.getElementById("notification").style.display = "none"
                    }, 3000);
                } 
            })
            .catch(error => {
                console.error('Error:', error);
                // Handle any network or other errors here
            });
        });   

        const passwordForm = document.getElementById("passwordForm");
    
        passwordForm.addEventListener("submit", (e) => {
            e.preventDefault(); // Corrected method name from defaultPrevented to preventDefault
    
            const oldPassword = document.getElementById("oldPassword").value;
            const newPassword = document.getElementById("newPassword").value;
    
            fetch('/changePassword', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    oldPassword: oldPassword,
                    newPassword: newPassword
                })
            })
            .then(response => response.json())
            .then(msg => {
                console.log(msg.error)
                if (msg.error) {
                    if(msg.error == "Success!"){
                        document.getElementById("notification").style.display = "block"
                    document.getElementById("notification").innerHTML = msg.error;
                    setTimeout(() => {
                        document.getElementById("notification").style.display = "none"
                        window.location.href = "/signout"
                    }, 3000);
                    return;
                    }
                    document.getElementById("notification").style.display = "block"
                    document.getElementById("notification").innerHTML = msg.error;
                    setTimeout(() => {
                        document.getElementById("notification").style.display = "none"
                    }, 3000);
                } 
            })
            .catch(error => {
                console.error('Error:', error);
                // Handle any network or other errors here
            });
        });   

}
