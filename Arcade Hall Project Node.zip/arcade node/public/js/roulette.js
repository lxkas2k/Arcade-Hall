window.onload = function () {

    const wheel = document.getElementById("wheel");
    const bet = document.getElementById("spin");
    const green = document.getElementById("green");
    const black = document.getElementById("black");
    const red = document.getElementById("red");
    const arrow = document.getElementById("arrow");
    const spinButton = document.getElementById("spin");
    const allinButton = document.getElementById("allin");
    const scrollAmount = 0;
    const step = 10 // Adjust the step size for smoother/slower scrolling
    const itemWidth = 100; // Width of each item
    const totalItems = 60; // Total number of items
    var clicked = false;
    var potentialWin = 0;
    red.statusClicked = true;
    green.statusClicked = true;
    black.statusClicked = true;
    let userTickets;

    fetch('/getTickets', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
    })
    .then(response => response.json())
    .then(data => {
        userTickets = data.tickets;
    })

    function addTickets(newNumber) {
        fetch('/addTickets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
                tickets: newNumber
            })
        })
        .then(response => response.json())
        .then(data => {
            userTickets = data.tickets;
            console.log(userTickets);
            document.getElementById("tickets2").innerHTML = "Your current Tickets: " + userTickets;
        })
    }
    function takeTickets(newNumber) {
        fetch('/takeTickets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
                tickets: newNumber
            })
        })
        .then(response => response.json())
        .then(data => {
            userTickets = data.tickets;
            document.getElementById("tickets2").innerHTML = "Your current Tickets: " + userTickets;
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }
    function showNotification(showNoti) {
        const notification = document.getElementById('notification');
        notification.style.display = 'block';

        if(showNoti == "win") {
            notification.style.backgroundColor = "#4CAF50";
            notification.innerHTML = "🎉You've won!"
        } else  if (showNoti == "lose"){
            notification.style.backgroundColor = "red";
            notification.innerHTML = "😢 LOOOOOSER!"
        }

        // Add animation class
        notification.classList.add('notification-show');

        // Automatically close after 5 seconds
        setTimeout(() => {
            closeNotification();
        }, 2000);
    }

    function closeNotification() {
        const notification = document.getElementById('notification');

        // Remove animation class
        notification.classList.remove('notification-show');

        // Hide notification after animation
        setTimeout(() => {
            notification.style.display = 'none';
        }, 2000); // Should match CSS animation duration
    }

    for (let i = 0; i < 100; i++) { // Erstellen von den Roulette Fekder
        const divElement = document.createElement("div");
        divElement.style.display = "inline-block";
        divElement.style.width = "100px";
        divElement.style.height = "100px";
        divElement.id = "color_bet";
        if (i % 2 == 0) {
            divElement.style.backgroundColor = "red"
        } else if (i % 31 == 0) {
            divElement.style.backgroundColor = "green"
        }
        else {
            divElement.style.backgroundColor = "black"
        }
        wheel.appendChild(divElement);
    }
    function stopAtRandomItem() {
        // Calculate the number of items visible within the container
        var visibleItems = Math.floor(wheel.clientWidth / itemWidth);

        // Calculate the range within which the wheel can stop
        var maxStopPosition = totalItems - visibleItems; // Maximum position to stop

        // Generate a random position within the allowed range
        var randomPosition = Math.floor(Math.random() * (maxStopPosition + 1));

        // Calculate the scroll position to stop at
        var stopScrollPosition = randomPosition * itemWidth + 45; // Adjusted stop position

        // Animate the scroll to stopScrollPosition
        animateScroll(stopScrollPosition);
    }

    function animateScroll(targetPosition) {
        var start = wheel.scrollLeft;
        var distance = targetPosition - start;
        var duration = 1000; // Animation duration in milliseconds
        var startTime = null;

        function animationStep(timestamp) {
            if (!startTime) startTime = timestamp;
            var progress = timestamp - startTime;
            var ease = easeOutQuart(progress, start, distance, duration);
            wheel.scrollLeft = ease;
            if (progress < duration) {
                requestAnimationFrame(animationStep);
            }
        }

        requestAnimationFrame(animationStep);
    }

    // Easing function for smooth animation
    function easeOutQuart(t, b, c, d) {
        t /= d;
        t--;
        return -c * (t * t * t * t - 1) + b;
    }

    // Event listener for the "Bet" button click

    allinButton.addEventListener("click", function () {
        const ticketsInput = document.getElementById("tickets-container")
        yourBet.innerHTML = "Potential win: " + userTickets;
        ticketsInput.value = userTickets;
    });

    spinButton.addEventListener("click", function () {
        const ticketsInput = document.getElementById("tickets-container").value.trim();
        console.log(userTickets);
        spinButton.disabled = true;

        if(userTickets <= 0){
            alert("You dont have any tickets anymore to play!");
            return;
        }
        if(ticketsInput > userTickets) {
            alert("You dont have this amount of tickets!");
            return;
        }
        if(ticketsInput <= 0){
            alert("You cant bet negative tickets");
            return;
        }
        if (red.statusClicked == true && green.statusClicked == true && black.statusClicked == true) {
            alert("Choose a color!")
            return;
        }

        // Reset variables and start scrolling
        var scrollAmount = 0;
        var intervalTime = 1;
        setTimeout(stopAtRandomItem, intervalTime);
        setTimeout(function () {
            spinButton.disabled = false;
            // Calculate the center coordinates of the arrow
            const arrow = document.getElementById("arrow");
            const rect = arrow.getBoundingClientRect();
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;
            const elementUnderArrow = document.elementFromPoint(centerX, centerY + 50);
            const color = elementUnderArrow.style.backgroundColor;
            // Get the position and dimensions of the arrow element
            if (color == "red" && red.statusClicked == false) {
                showNotification("win");
                addTickets(ticketsInput * 2);
            } else if (color == "black" && black.statusClicked == false) {
                showNotification("win");
                addTickets(ticketsInput * 2);
            } else if (color == "green" && green.statusClicked == false) {
                showNotification("win");
                addTickets(ticketsInput * 14);
            }
            else {
                showNotification("lose");
                takeTickets(ticketsInput * -1);
            }
        }, 1000)

    });

    function buttonClicked(multiplier, event) {
        function setButtons(mainobj, obj1, obj2) {
            if (mainobj.statusClicked == true) { // turn off
                mainobj.statusClicked = false;
                mainobj.style.border = "2px solid white"
                obj1.disabled = true;
                obj2.disabled = true;
                potentialWin = tickets * multiplier;
            }
            else if (mainobj.statusClicked == false) { // turn on
                mainobj.style.border = "none"
                mainobj.statusClicked = true;
                obj1.disabled = false;
                obj2.disabled = false;
                potentialWin = 0;
            }
        }

        var tickets = document.getElementById("tickets-container").value.trim();
        if (tickets === '') {
            alert("bet tickets!");
            return;
        }
        if (this == red) {
            setButtons(red, black, green);
        }
        if (this == black) {
            setButtons(black, green, red);
        }
        if (this == green) {
            setButtons(green, black, red);
        }
        document.getElementById("yourBet").innerHTML = "Potential win: " + potentialWin;

        if (red.statusClicked == false) {
            spinButton.style.backgroundColor = "red";
        }
        else if (black.statusClicked == false) {
            spinButton.style.backgroundColor = "black";
        }
        else if (green.statusClicked == false) {
            spinButton.style.backgroundColor = "green";

        } else {
            spinButton.style.backgroundColor = "#5449dc";
        }
    }


    red.addEventListener("click", buttonClicked.bind(red, 2));
    black.addEventListener("click", buttonClicked.bind(black, 2));
    green.addEventListener("click", buttonClicked.bind(green, 14));

}