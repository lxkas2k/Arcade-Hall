window.onload = function(){
    const passwordField = document.getElementById('password');
    const togglePassword = document.getElementById('togglePassword');
    const loginButton = document.getElementById("loginButton");
    let alert = document.getElementById("alertbox");
    alert.style.display = "none";
    document.getElementById('togglePassword').addEventListener('click', function(){
        if (passwordField.type === 'password') {
            passwordField.type = 'text';
            togglePassword.src = 'images/eye-solid.svg'; 
        } else {
            passwordField.type = 'password';
            togglePassword.src = 'images/eye-slash-solid.svg'; 
        }
    });
// Assuming you have a form with id 'myForm' and fields 'username' and 'password'
const login = document.getElementById("loginSubmit");


login.addEventListener("submit", function(event){
    event.preventDefault(); // Prevent the form from submitting normally
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    // For demonstration purposes, we will send a basic POST request to a server
    fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ 
            username:username,
            password:password
        })
    })
    .then(response => response.json())
    .then(data => {
        console.log(data.loggedIn);
        if(data.loggedIn){
            alert.innerHTML = "You're logged in!<br>You'll be redirected in 3 seconds!";
            alert.style.display = "block";
            setTimeout(() => {
                window.location.href = "/index";
                return;
            }, 3000);
        }else{
            alert.innerHTML = data.error;
            alert.style.display = "block";
            setTimeout(() => {
                alert.style.display = "none";
            }, 3000);
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
});

}
