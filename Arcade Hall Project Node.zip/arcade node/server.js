const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;
const getRoutes = require('./routes/getRoutes'); // Import the router from routes.js
const postRoutes = require('./routes/postRoutes'); // Import the router from routes.js
const { connection, promiseQuery } = require('./db');
const session = require('express-session');
const { router: uploadRouter } = require('./upload');
let msgs = [];
let currentUser = "";
let currentTickets = 0;
let messagesLoaded = false;
let c = 0;
app.use(session({
  secret: 'your-secret-key', // Replace with your own secret key
  resave: false,
  saveUninitialized: true,
  cookie: {
    secure: false, // Set to true in production with HTTPS
    maxAge: (24 * 60 * 60 * 1000) * 1000 // 1 day in milliseconds
  }
}));

function sessionChecker(req, res, next) {
  if (req.session.isLoggedIn) {
    res.locals.isLoggedIn = true;
    res.locals.username = req.session.username;
    res.locals.tickets = req.session.tickets;
    res.locals.profilepic = req.session.profilepic;
  } else {
    res.locals.isLoggedIn = false;

  }
  next();
}

app.set('view engine', 'ejs');
app.use(bodyParser.json()); // Parse JSON bodies
app.use(bodyParser.urlencoded({ extended: true })); // Parse URL-encoded bodies
app.use(express.static('public')); // Serve static files (e.g., CSS, images)
app.use(sessionChecker);
app.use('/', getRoutes);
app.use('/', postRoutes);
app.use('/', uploadRouter);

app.listen(port, () => console.log(`Server is running on http://localhost:${port}`));
