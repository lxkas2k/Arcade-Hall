const mysql = require('mysql');

// Create connection
const connection = mysql.createConnection({
    host: 'localhost', // Your MySQL server hostname
    user: 'root',      // Username
    password: '',  // Password
    database: 'arcade' // Name of your database
  });

// Connect to MySQL
const promiseQuery = (sql, args) => {
    return new Promise((resolve, reject) => {
      connection.query(sql, args, (err, rows) => {
        if (err) return reject(err);
        resolve(rows);
      });
    });
  };
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL database: ' + err.stack);
    return;
  }
  
  console.log('Connected to MySQL database as ID ' + connection.threadId);
});

module.exports = {
    connection,
    promiseQuery
  };
