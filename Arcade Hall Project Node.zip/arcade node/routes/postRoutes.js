const express = require('express');
const router = express.Router();
const getRoutes = require('./getRoutes');
const { connection, promiseQuery } = require('../db');
const { giveStandardUsername, replaceImage } = require('../upload');
router.post("/signup", async (req, res) => {
  const username = req.body.username;
  const password = req.body.password;
  try {
    const user = await promiseQuery('SELECT username FROM users WHERE username = ?', [username]);

    if (user.length > 0) {
      res.json({ error: "Username already exists" })
      return;
    } else {
      await promiseQuery('INSERT INTO `users` (`username`, `password`, `tickets`) VALUES (?, ?, ?)', [username, password, 100]);
      req.session.cr = 0;
      req.session.signInSuccess = true
      res.json({ signedIn: true })
      giveStandardUsername(username);
    }
  } catch (error) {
    console.error('Error executing query:', error);
    res.status(500).send('Internal server error');
  }
});
router.post("/login", async (req, res) => {
  const usernameInput = req.body.username;
  const password = req.body.password;
  try {
    const user = await promiseQuery('SELECT password,tickets FROM users WHERE username = ?', [usernameInput]);
    if (user.length == 0) {
      res.json({ error: "This username doesnt exist" })
      return;
    } else {
      if (password == user[0].password) {
        console.log("login successful, redirecting");
        req.session.isLoggedIn = true;
        req.session.username = usernameInput;
        req.session.tickets = user[0].tickets;
        req.session.cl = 0;
        res.json({ loggedIn: true })
        return;
      } else {
        res.json({ error: "Wrong Password! Try again!" })
      }
    }
  } catch (error) {
    console.error('Error executing query:', error);
    res.status(500).send('Internal server error');
  }
});
function modifyTickets(action, redirect) {
  router.post(action, async (req, res) => {
    const tickets = req.session.tickets = parseInt(req.body.tickets) + parseInt(req.session.tickets);
    const username = req.session.username;
    await promiseQuery('UPDATE `users` SET `tickets` = ? WHERE `username` = ?', [tickets, username]);
    res.json({ tickets: req.session.tickets });
  });
}
modifyTickets("/takeTickets", "/roulette");
modifyTickets("/addTickets", "/roulette");
modifyTickets("/takeTicketsB", "/kartenspiel");
modifyTickets("/addTicketsB", "/kartenspiel");

router.post("/changePassword", async (req, res) => {
  oldpassword = req.body.oldPassword;
  newpassword = req.body.newPassword;
  username = req.session.username;

  const checkoldPassword = await promiseQuery(
    "SELECT password FROM `users` WHERE username LIKE ?", [username], function (error) {

      if (error) {
        console.log(error);
        return;
      }
      console.log("password changed successfully");

    });

  let specialChars = [' ', '!', '?', '"', '#', '%', '&', '{', '}', '(', ')', '[', ']', '\\', '/', '<', '>', '*', ' ', '$', ':', ';', '@', '+', '-', '=', '\u00A7']
  var noSpecialChar = false;

  for (let i = 0; i < specialChars.length; i++) {

    if (newpassword.includes(specialChars[i]) == false) {
      noSpecialChar = true;

    } else {
      noSpecialChar = false;
      break;
    }
  }

  if (noSpecialChar) {
    res.json({ error: "Use minimum one special character!" });
    return;
  }


  if (/[A-Z]/.test(newpassword) == false) {
    res.json({ error: "Use minimum one uppercase letter!" });
    return;
  }

  if (/[0-9]/.test(newpassword) == false) {
    res.json({ error: "Use at least one number!" });
    return;
  }


  if (newpassword.length <= 7) {
    res.json({ error: "Password is too short. Minimum 8 letters!" });
    return;
  }
  if (checkoldPassword[0].password == oldpassword) {
    res.json({ error: "Success!" });
    await promiseQuery(
      "UPDATE `users` SET `password`= ? WHERE `username` LIKE ?", [newpassword, username], function (error) {
        if (error) {
        }
      });

  } else {
    res.json({ error: "wrong password!" });
    return;
  }

});

router.post("/getTickets", async (req, res) => {
  res.json({ tickets: req.session.tickets })
  console.log("a");
});


module.exports = router;