const multer = require('multer');
const path = require('path');
const express = require('express');
const router = express.Router();
const fs = require('fs')
const { connection, promiseQuery } = require('./db');
function replaceImage(oldImg, newImg, callback) {
    fs.copyFile("./public/username_profiles/"+oldImg, "./public/username_profiles/"+newImg, (err) => {
      if (err) {
        return callback(err);
      }
      fs.unlink("./public/username_profiles/"+oldImg, (err) => {
        if (err) {
            console.error('Error deleting file:', err);
            return;
        }
    });
      return;
    });
  }

function giveStandardUsername(name){
    copyAndRenameImage(name + ".png", (err, targetPath) => {
      if (err) {
        console.error('Copy and rename operation failed:', err);
      } else {
      }
    });
  }

// Function to copy and rename image file
function copyAndRenameImage(newFileName, callback) {
    const readStream = fs.createReadStream("./public/username_profiles/standard_profile.png");
    const targetPath = path.join('./public/username_profiles/', newFileName);
    const writeStream = fs.createWriteStream(targetPath);
  
    readStream.pipe(writeStream);
  
    writeStream.on('finish', () => {
      console.log(`Image copied and renamed successfully to ${targetPath}`);
    });
  
    writeStream.on('error', (err) => {
      console.error('Error copying image:', err);
    });
  }

// Define storage for the uploaded files
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './public/username_profiles'); // Specify the directory for storing files
  },
  filename: function (req, file, cb) {
    cb(null, req.session.username + path.extname(file.originalname)); // Specify the filename
  }
});

// Initialize multer middleware with the defined storage
const upload = multer({ storage: storage });


router.post("/changeUsername", async (req, res) => {
  username = req.body.username;
  currentUsername = req.session.username;
  password = req.body.password;
  const checkUsername = await promiseQuery(
    "SELECT username from users where username = ?", [username]);
  if (checkUsername.length > 0) {
    res.json({ error: "There is already a user with this username!" });
    return;
  }
  const result = await promiseQuery(
    "UPDATE users SET username = ? WHERE username = ? AND password = ?",
    [username, currentUsername, password]
  );
  const numRowsAffected = result.affectedRows;
  if (numRowsAffected > 0) {
    res.json({ error: "Success!" });
    return;
  } else {
    res.json({ error: "Wrong Password" });
    return;
  }
});

router.post('/changeProfilepic', upload.single('filename'), (req, res) => {
  newImg = req.file.filename;
  oldImg = req.session.username + ".png"
  replaceImage(newImg,oldImg);
});

router.post('/upload', upload.single('file'), (req, res) => {
  res.send('File uploaded successfully');
});

module.exports = { router, giveStandardUsername,replaceImage};
