function createCard(player) {
    function getRandomNumber(min, max) {
        // Generate a random number between min and max (inclusive)
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }    
    var card = document.createElement('img');
    let cards = [2, 3, 4, 5, 6, 7, 8, 9, 10, 'Ace', 'Jack', 'King', 'Queen'];
    let cardNames = ["diamonds", "hearts", "spades", "clubs"]
    let number = getRandomNumber(0, 12);
    var src = "cards/" + cards[number] + "_of_" + cardNames[getRandomNumber(0, 3)] + ".svg";
    card.src = src;
    card.classList.add('cards');
    player.append(card);
    cardValue = cards[number];
    if (/\D/.test(cardValue) == false) {
        return cardValue;
    } else {
        if (cardValue.includes("Ace")) {
            return 11;
        }
        return 10;
    }
}

window.onload = function () {
    function modifyTickets(action,newNumber){
        fetch(action, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
                tickets: newNumber
            })
        })
        .then(response => response.json())
        .then(data => {
            userTickets = data.tickets;
            document.getElementById("tickets").innerHTML = "Your current Tickets: " + userTickets;
        })
    }
    

    const dealer = document.getElementById("dealer");
    const player = document.getElementById("player");
    const stay = document.getElementById("stay");
    const bet = document.getElementById("bet");
    const eingabe = document.getElementById("eingabe");
    const yourbet = document.getElementById("yourbet");
    const score_p = document.getElementById("player_score");
    const score_d = document.getElementById("dealer_score");
    var sum_player = 0;
    var sum_dealer = 0;
    var stayStatus = false;
    var count = 0;

    bet.disabled = true;

    eingabe.addEventListener('input', function(event) {

        if (eingabe.value.trim() !== '') {
            bet.disabled = false;
        } else {
            bet.disabled = true;
        }
        
        yourbet.innerHTML = 'Your Bet: ' + eingabe.value;

        const validCharacters = /^[0-9]*$-/;
        let value = event.target.value;

        if (!validCharacters.test(value)) {
            value = value.replace(/[^0-9]*$-/, '');
            event.target.value = value;
        }
    });

    if(eingabe.value == "") {
        hit.disabled = true;
    } else {
        hit.disabled = false;
    }

    if(eingabe.value == "") {
        stay.disabled = true;
    } else {
        stay.disabled = false;
    }

    hit.addEventListener("click", function () {

        if (count == 0) {
            card_value = createCard(dealer);
            sum_dealer += card_value;
            score_d.innerHTML = "Dealer score: " + sum_dealer;
        }
        count++;
        card_value = createCard(player);
        sum_player += card_value;
        score_p.innerHTML = "Player score: " + sum_player;
        if (sum_player > 21) {
            score_p.innerHTML = "Player score: " + sum_player;
            gewinnAusgabe("Dealer")
            modifyTickets("/takeTicketsB",eingabe.value * -1);
            setTimeout(function(){
                location.reload();
            },1000);
        }
        
        if (sum_player == 21) {
            hit.disabled = true;
        }

        console.log(sum_player);
    });
    stay.addEventListener("click", function () {
        hit.disabled = true;
        stay.disabled = true;
        while (sum_dealer <= 17) {
            card_value = createCard(dealer);
            sum_dealer += card_value;
            score_d.innerHTML = "Dealer score: " + sum_dealer;
        }
        if (sum_player == sum_dealer) {
            score_d.innerHTML = "Dealer score: " + sum_dealer;
            gewinnAusgabe("Unentschieden");
            hit.disabled = true;
            stay.disabled = true;
        }
        else if (sum_dealer > 21 || sum_player > sum_dealer || sum_player == 21) {
            score_d.innerHTML = "Dealer score: " + sum_dealer;
            gewinnAusgabe("Spieler");
            modifyTickets("/addTicketsB",eingabe.value * 2);
            hit.disabled = true;
            stay.disabled = true;
        }
        else if (sum_dealer > sum_player && sum_dealer <= 21) {
            gewinnAusgabe("Dealer");
            modifyTickets("/takeTicketsB",eingabe.value * -1);
            hit.disabled = true;
            stay.disabled = true;
        }
    })

    bet.addEventListener("click", function () {
        bet.disabled = true;
        hit.disabled = false;
        stay.disabled = false;
        eingabe.disabled = true;
    })

    function gewinnAusgabe(name) {
        setTimeout(function () {
            alert("Der " + name + " hat gewonnen!");
        }, 100);

        setTimeout(function () {
            sum_player = 0;
            sum_dealer = 0;
            stayStatus = false;
            count = 0;
            hit.disabled = true;
            stay.disabled = true;
            bet.disabled = true;
            eingabe.disabled = false;
            player.innerHTML = "";
            dealer.innerHTML = "";
            eingabe.value = "";
            yourbet.innerHTML = "Your Bet: ";
            score_p.innerHTML = "Player score: 0";
            score_d.innerHTML = "Dealer score: 0";
        }, 100);
    }

    function showNotification(showNoti) {
        const notification = document.getElementById('notification');
        notification.style.display = 'block';

        if(showNoti == "win") {
            notification.style.backgroundColor = "#4CAF50";
            notification.innerHTML = "🎉You've won!"
        } else  if (showNoti == "lose"){
            notification.style.backgroundColor = "red";
            notification.innerHTML = "😢 LOOOOOSER!"
        }

        // Add animation class
        notification.classList.add('notification-show');

        // Automatically close after 5 seconds
        setTimeout(() => {
            closeNotification();
        }, 2000);
    }

    function closeNotification() {
        const notification = document.getElementById('notification');

        // Remove animation class
        notification.classList.remove('notification-show');

        // Hide notification after animation
        setTimeout(() => {
            notification.style.display = 'none';
        }, 2000); // Should match CSS animation duration
    }
}