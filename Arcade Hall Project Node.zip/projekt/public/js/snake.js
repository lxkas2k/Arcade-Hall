window.onload = function () {
    const head = document.getElementById("head");
    const game = document.getElementById("game");
    const scoreDisplay = document.getElementById("score");

    const boxSize = 50;  // Size of each segment of the snake
    let snake = [{x: 0, y: 0, element: head}];  // Array representing the snake, starting with the head
    let direction = 'RIGHT';  // Initial direction of the snake
    let score = 0;
    let speed = 200;  // Speed in milliseconds
    let apple = null;
    let gameOverAlertShown = false; // Flag to track if game over alert is shown

    function addTickets(newNumber) {
        fetch('/addTickets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
                tickets: newNumber
            })
        })
    }

    // Initialize snake body
    for (let i = 1; i < 5; i++) {
        createBody(-boxSize * i, 0);
    }

    function createBody(x, y) {
        const bodyPart = document.createElement("div");
        bodyPart.classList.add("body");
        bodyPart.style.width = `${boxSize}px`;
        bodyPart.style.height = `${boxSize}px`;
        bodyPart.style.backgroundColor = "red";
        bodyPart.style.position = "absolute";
        bodyPart.style.left = `${x}px`;
        bodyPart.style.top = `${y}px`;
        game.appendChild(bodyPart);
        snake.push({x, y, element: bodyPart});
    }

    function setDirection(event) {
        switch (event.key) {
            case 'ArrowUp':
                if (direction !== 'DOWN') direction = 'UP';
                break;
            case 'ArrowDown':
                if (direction !== 'UP') direction = 'DOWN';
                break;
            case 'ArrowLeft':
                if (direction !== 'RIGHT') direction = 'LEFT';
                break;
            case 'ArrowRight':
                if (direction !== 'LEFT') direction = 'RIGHT';
                break;
        }
    }

    document.addEventListener('keydown', setDirection);

    function updatePosition() {
        // Move snake head
        let headX = snake[0].x;
        let headY = snake[0].y;

        switch (direction) {
            case 'UP':
                headY -= boxSize;
                break;
            case 'DOWN':
                headY += boxSize;
                break;
            case 'LEFT':
                headX -= boxSize;
                break;
            case 'RIGHT':
                headX += boxSize;
                break;
        }

        // Check for wall collisions
        if (headX < 0 || headX >= game.offsetWidth || headY < 0 || headY >= game.offsetHeight) {
            gameOver();
            return;
        }

        // Check for self-collision
        for (let i = 1; i < snake.length; i++) {
            if (snake[i].x === headX && snake[i].y === headY) {
                gameOver();
                return;
            }
        }

        // Check for apple collision
        if (apple && headX === apple.x && headY === apple.y) {
            eatApple();
        }

        // Move the snake body
        for (let i = snake.length - 1; i > 0; i--) {
            snake[i].x = snake[i - 1].x;
            snake[i].y = snake[i - 1].y;
            snake[i].element.style.left = `${snake[i].x}px`;
            snake[i].element.style.top = `${snake[i].y}px`;
        }

        // Update head position
        snake[0].x = headX;
        snake[0].y = headY;
        head.style.left = `${headX}px`;
        head.style.top = `${headY}px`;
    }

    function gameOver() {
        if (!gameOverAlertShown) {
            gameOverAlertShown = true; // Set flag to true
            alert("Game Over! Your score is " + score + "\nYou earned " + score / 5 + " Tickets!");
            addTickets(score / 5);
            // Reload the page to restart the game
            window.location.reload();
        }
    }

    function gameLoop() {
        updatePosition();
    }

    function createApple() {
        const appleElement = document.createElement("div");
        appleElement.classList.add("apple");
        appleElement.style.width = `${boxSize}px`;
        appleElement.style.height = `${boxSize}px`;
        appleElement.style.backgroundColor = "green";
        appleElement.style.position = "absolute";

        let x, y;
        let isOnSnake;

        do {
            x = Math.floor(Math.random() * (game.offsetWidth / boxSize)) * boxSize;
            y = Math.floor(Math.random() * (game.offsetHeight / boxSize)) * boxSize;

            isOnSnake = snake.some(segment => segment.x === x && segment.y === y);
        } while (isOnSnake);

        appleElement.style.left = `${x}px`;
        appleElement.style.top = `${y}px`;
        game.appendChild(appleElement);

        apple = {x, y, element: appleElement};
    }

    function eatApple() {
        // Remove the apple element from the game
        game.removeChild(apple.element);
        apple = null;

        // Increase the score
        score += 10;
        scoreDisplay.innerText = `Score: ${score}`;

        // Add a new body segment to the snake
        const tail = snake[snake.length - 1];
        createBody(tail.x, tail.y);

        // Create a new apple
        createApple();
    }

    // Create the first apple
    createApple();

    setInterval(gameLoop, speed);  // Call the gameLoop function every `speed` milliseconds
}
