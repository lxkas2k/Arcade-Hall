window.onload = () => {
    const availablePolls = document.getElementById("availablePolls");
    const poll = document.getElementById("newPoll");
    const pollContainer = document.getElementById("pollContainer");
    const addAnswer = document.getElementById("addAnswer");
    const submit = document.getElementById("submit");

    let counter = 0;

    getPolls();

// Function to create input field and close button
function createInputField(counter, placeholder) {
    const inputContainer = document.createElement("div");
    const input = document.createElement("input");
    input.type = "text";
    input.placeholder = placeholder;
    input.id = input.name = "Answer" + counter;
    input.classList.add("input");

    const closeBtn = document.createElement("div");
    closeBtn.classList.add("close-button");
    closeBtn.id = counter;
    closeBtn.innerHTML = "&times;";
    if(placeholder != "Question"){
        inputContainer.append(input, closeBtn);
    }else{
        input.style.right = "20px";
        inputContainer.append(input);
    }

    inputContainer.classList.add("inputContainer");
    inputContainer.id = "div" + counter;
    // Add click event listener to close button
    closeBtn.addEventListener('click', (event) => {
         document.getElementById("div" + event.target.id).remove();
         counter--;
    });

    return inputContainer;
}

// Add answer button click event
addAnswer.addEventListener("click", () => {
    const inputContainer = createInputField(counter, "Answer ");
    poll.append(inputContainer);
    counter += 1;
});

// Create poll button click event
createPoll.addEventListener("click", () => {
    for (let i = 1; i < 4; i++) {
        const placeholder = (i == 1) ? "Question" : "Answer ";
        const inputContainer = createInputField(counter, placeholder);
        poll.append(inputContainer);
        counter += 1;
    }

    availablePolls.style.display = "none";
    pollContainer.style.display = "flex";
    createPoll.style.display = "none";
    submit.style.display = "block";
});


    submit.addEventListener("click", () => {
        availablePolls.style.display = "flex";
        pollContainer.style.display = "none";
        createPoll.style.display = "block";
        submit.style.display = "none";
        const question = document.getElementById("Answer0").value;
        let answers = [];
        for (let i = 1; i < counter; i++) {
            answers.push(document.getElementById("Answer" + i).value);
        }   
        const formData = {
            question: question,
            answers: answers
        };
        fetch('submitPoll',{
            method: 'POST',
            headers : {
                'Content-Type': 'application/json'//tells what datatype body is
            },
            body: JSON.stringify(formData)
        })
        .then(response => response.json())
        .then(user =>{
           // document.getElementById("username").innerHTML =user.username;
        });
        counter = 1;
        poll.innerHTML = "";
        getPolls();
    })
}