const express = require('express');
const router = express.Router();
const postRoutes = require('./postRoutes');
const { redirect } = require('express/lib/response');
const {giveStandardUsername} = require('../upload');
const { connection, promiseQuery } = require('../db');

router.get('/', (req, res) => {
  res.redirect('/index');
});

router.get('/index', (req, res) => {
  if(req.session.isLoggedIn){
    req.session.cl += 1;
  }
  res.render('index', {
    isLoggedIn: req.session.isLoggedIn,
    username: req.session.username,
    tickets: req.session.tickets,
    profile: req.session.profilepic,
    counter: req.session.cl
  });
});

router.get('/aimlabs', (req, res) => {
  res.render('aimlabs', {
    isLoggedIn:req.session.isLoggedIn,
    username: req.session.username,
    tickets:req.session.tickets
  });
});

router.get('/chuj', (req, res) => {
  res.render('chuj', {
    isLoggedIn:req.session.isLoggedIn,
    username: req.session.username,
    tickets:req.session.tickets
  });
});

router.get('/dodger', (req, res) => {
  res.render('dodger', {
    isLoggedIn: req.session.isLoggedIn,
    username: req.session.username,
    tickets: req.session.tickets
  });
});

router.get('/eater', (req, res) => {
  res.render('eater', {
    isLoggedIn: req.session.isLoggedIn,
    username: req.session.username,
    tickets: req.session.tickets
  });
});
router.get('/bmi', (req, res) => {
  res.render('bmi', {
    isLoggedIn: req.session.isLoggedIn,
    username: req.session.username,
    tickets: req.session.tickets
  });
});
router.get('/cal', (req, res) => {
  res.render('cal', {
    isLoggedIn: req.session.isLoggedIn,
    username: req.session.username,
    tickets: req.session.tickets
  });
});
router.get('/timer', (req, res) => {
  res.render('timer', {
    isLoggedIn: req.session.isLoggedIn,
    username: req.session.username,
    tickets: req.session.tickets
  });
});
router.get('/kartenspiel', (req, res) => {
  res.render('kartenspiel', {
    isLoggedIn: req.session.isLoggedIn,
    username: req.session.username,
    tickets: req.session.tickets
  });
});

router.get('/snake', (req, res) => {
  res.render('snake', {
    isLoggedIn: req.session.isLoggedIn,
    username: req.session.username,
    tickets: req.session.tickets
  });
});

router.get('/highscore', async(req, res) => {
  const highscore = await promiseQuery("SELECT username, tickets FROM users ORDER BY tickets DESC LIMIT 5;");
  res.render('highscore', {
    isLoggedIn: req.session.isLoggedIn,
    username: req.session.username,
    tickets: req.session.tickets,
    highscore : highscore
  });
});

router.get("/ticketsAmount",(req,res) =>{
  const data = { tickets: req.session.tickets };
  res.json(data);
});


router.get('/roulette', (req, res) => {
  res.render('roulette', {
    isLoggedIn: req.session.isLoggedIn,
    username: req.session.username,
    tickets: req.session.tickets
  });
});
router.get('/login', (req, res) => {
  if(req.session.signInSuccess == true){
    req.session.cr += 1;
  }
  isLoggedIn = req.session.isLoggedIn;
  if(isLoggedIn){
    res.render("index");
  }else{
    res.render("login",{
      counter: req.session.cr,
      wrongUsername : req.session.wrongUsername
    });
  }
});

router.get('/register', (req, res) => {
  isLoggedIn = req.session.isLoggedIn;
  if(isLoggedIn){
    res.render("index");
  }else{
    res.render("register");
  }
});
router.get('/signout', (req, res) => {
  req.session.isLoggedIn = false;
  res.redirect('/login');
});
router.get('/profile', (req, res) => {
  res.render('profile', {
    isLoggedIn: req.session.isLoggedIn,
    username: req.session.username,
    tickets: req.session.tickets,
    error: req.session.error
  });
});


module.exports = router;
